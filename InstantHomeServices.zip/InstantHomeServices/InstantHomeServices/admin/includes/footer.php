 <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; 2022 <strong>Instant Home Services </strong>. All Rights Reserved
        </p>
        <div class="credits">
         
          
        </div>
       
      </div>
    </footer>