
Run the script http://localhost/on-demand-home-service

Admin Credential
Username: admin
Password: admin123

Technician Credential
Username: Tech104
Password: 123


User Credential
Username: raja@gmail.com
Password: 123
Or You can register yourself as a user.

